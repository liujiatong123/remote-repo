import axios from 'axios'
const instance = axios.create({
    // baseURL:'http://v.juhe.cn/toutiao/index',
    baseURL:"/api",
    timeout:1000,
    // headers:{
    //     "Content-Type":"application/x-www-form-urlencoded",
    //     'Access-Control-Allow-Origin': '*',
    // }
})
export default instance;