<template>
  <div id="app">
    <van-row type="flex" justify="space-between">
      <van-col span="3">
        <van-image
        round
        width="3rem"
        height="3rem"
        fit="fill"
        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAclBMVEUAAADl5eXn5+fl5eXq6uro6Ojm5ubj4+Pk5OTt7e3p6enj4+Pn5+ff39/i4uL/////Nzzr6+v/zc7/UFT/5uf/aWz/tLb/m53/goX/REj/XGD/8vP/qKr/jpH/2tr/dXn/wML/goTx8fH19fX/m57/tLW8xwRAAAAAD3RSTlMAXyCf78+/QKDv34B/EFBAdW3pAAADr0lEQVRo3u2a7XaiMBCGg59tt3Ykk5DwTdW9/1vcatARBjFVck737D7/2oPvE5JJnELFFZtovlzET/K6nEczMcR6Fe9hEvbxfM3iZ6sdTMhu3ruLaLGHaXmLrvPfdzA5u3eWH8wQUf60ho92fd8gEAu30i8Qiv3qVP87CMZuTTcQhpUQsxgCEm9EtIeA7COaoTDMxRKCshSvEJSFiCEo8dSCXCkpk6QwxtpaZ4hPCVQ/bcshgXdaeTvNX6BUJZs2TWscTPMXtGnmnJZuJ0RQWhhE7+f/gskEaKmwgggUQKJ7Tsx0/flZmgL9BenpQ3ywxu2W0pgiSaRUSsEVelzAgyybIGBMK1CPCiqZFOZTZzguMPCogK7JK4m3BAjPCIijoBgSSDjCz7CsageH/oLkMiLCQkuC3YnL2/xs+5wAKxhQaAUOhdsHBcSBLmpqFy+hRaajOznNdF2a49YZEBCoSKESXV7i89L/qEhpPd2kspvgSPzuWSTbyeJgAgwa/jMCUkjWs8ii1qNrAHlvL7u5HppAXVTg4JrGZONVRNvFlTYLL2UOo1jfMnV10rmGh1fqYQG62uDLQqjD16RntlEPCbTbTExA6bRFsDZS3RNUqiso4YgZFshDdvmqzC7LU5tG5l0B28vW7WU8H6Y1F6iibstRO1k/hQk4tzayrApLnx8UpOgpSOHWNugL1LGZSJJGVkqxNbiNZaM7VoxrTaiZYHgLUDrBOS0HSFiZ+gvSU9tkKI3znMBCl58lyCvZsD+vHhV0mwkqBIafoJOGKS/Tbwjyy9istdV5yGOkV4LsuAdyyPGGYLg7VOmNCnY7Sl3fQQNDNyPG8t1wCrc/O61FcjkPSYBtZdceAnNdbSXdTG+9ii0J6MI8vSv4DY5D54AuaOqVUyIJ2IUjgrSh/BNZv2k2dH8kuJokPSrAivK7gVW3fa94mfLZ5AJULN9NCX21tXeITMAniQsynu9SKNPSBUyA7XMZvCWw+XAXWABVo+pMQ3banAf6MhttHUtw5Nb9zOrm6/e1OziyrR9iqPxz/mlkT3keENTtMaRZlC9/08OQf0eQTipARK2PXZO59GCxeDqNOjqOr8B10Pc6On8B4v0ezF/A0n7403cuWEBQXoO/Ygn+kij8a65N2Bd1MyFWEJB54Jel8Vp8sQq3CnP3wjrYVnibiRMfoV65R6LlVxDD7pcQZAiTT0RvMC37xYfoMHuJJx3+aib6rF+m++eZ1VoMMYtelq/xkyyW82gjiD8U9zbr32NaBwAAAABJRU5ErkJggg=="
      />
      </van-col>
      <van-col span="21">
        <div style="display:flex;flex-grow: 1;">
          <van-search v-model="value" placeholder="请输入搜索关键词" shape="round"/>
        </div>
      </van-col>
    </van-row>
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    >
    <van-cell v-for="item in search" :key="item.uniquekey">
    <div><a :href="item.url" target="_blank">{{ item.title }}</a></div>
    <div style="display:flex">
      <div v-if="item.thumbnail_pic_s != ''">
        <img :src="item.thumbnail_pic_s"/>
      </div>
      <div v-if="item.thumbnail_pic_s02 != ''">
        <img :src="item.thumbnail_pic_s02"/>
      </div>
      <div v-if="item.thumbnail_pic_s03 != ''">
        <img :src="item.thumbnail_pic_s03"/>
      </div>
    </div>
    
    <div style="display:flex;justify-content: space-between;">
      <span>
        {{ item.date }}
      </span>
      <span>
        {{ item.author_name }}
      </span>
    </div>
  </van-cell>
</van-list>
  <van-pagination v-model="currentPage" :page-count="50" mode="simple" @change="onLoad"/>
  </div>
</template>

<script>
import instance from './utils/https/index'
export default {
  name: 'App',
  data(){
    return {
      value: '',
      list: [],
      loading: false,
      finished: false,
      currentPage:1
    }
  },
  computed:{
    search(){
      return this.list.filter((item)=>{return item.title.includes(this.value)})
    }
  },
  mounted(){
    // this.onLoad()
  },
  methods: {
    async onLoad() {
      let data = await instance({
        method:"GET",
        url:"/toutiao/index",
        params:{
          "key":"eb1ace0aa75af73260301171b3b7cd1d",
          "page":this.currentPage
        }
      });
      console.log(data)
      this.list = data.data.result.data
      this.$forceUpdate()
      console.log(this.list)
      this.loading = false;
      this.finished = true;
    },
  },
  components: {
  }
}
</script>

<style>
 .van-icon-chat-o{
  font-size: 40px;
 }
 .van-nav-bar__right{
  flex-grow: 1;
  display: flex;
 }
 .van-cell:not(.van-field){
  /* height:100px; */
  display:flex;
  flex-direction: column;
  justify-content: space-between;
 }
 .van-cell__value{
  display:flex;
  flex-direction: column;
  justify-content: space-between;
 
 }
 .van-search{
  flex-grow: 1;
 }
 a{
  text-decoration: none;
  color: inherit;
 }
</style>
